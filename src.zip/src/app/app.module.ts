import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import {SelectButtonModule} from 'primeng/selectbutton';
import {ButtonModule} from 'primeng/button';
import {RadioButtonModule} from 'primeng/radiobutton';
import {DropdownModule} from 'primeng/dropdown';
import {TabViewModule} from 'primeng/tabview';
import {FileUploadModule} from 'primeng/fileupload';
import {StepsModule} from 'primeng/steps';
import {ToastModule} from 'primeng/toast';
import {TableModule} from 'primeng/table';
import {MultiSelectModule} from 'primeng/multiselect';
import {InputTextModule} from 'primeng/inputtext';
import {DialogModule} from 'primeng/dialog';
import {InputMaskModule} from 'primeng/inputmask';
import {DynamicDialogModule} from 'primeng/dynamicdialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';

import { ModifyDeviceDefintionComponent } from './components/steps/modify-device-defintion/modify-device-defintion.component';
import { DisplayDeviceListComponent } from './components/steps/display-device-list/display-device-list.component';
import { ImportTableExcelComponent } from './components/steps/import-table-excel/import-table-excel.component';
import { CreatePageComponent } from './components/pages/create-page/create-page.component';
import { RevisionPageComponent } from './components/pages/revision-page/revision-page.component';
import { AddLayerComponent } from './components/dialog/add-layer/add-layer.component';

@NgModule({
  declarations: [
    AppComponent,
    ModifyDeviceDefintionComponent,
    DisplayDeviceListComponent,
    ImportTableExcelComponent,
    CreatePageComponent,
    RevisionPageComponent,
    AddLayerComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    SelectButtonModule,
    ButtonModule,
    RadioButtonModule,
    DropdownModule,
    TabViewModule,
    FileUploadModule,
    StepsModule,
    ToastModule,
    TableModule,
    MultiSelectModule,
    InputTextModule,
    DialogModule,
    InputMaskModule,
    DynamicDialogModule,
    ConfirmDialogModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
