import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportTableExcelComponent } from './import-table-excel.component';

describe('ImportTableExcelComponent', () => {
  let component: ImportTableExcelComponent;
  let fixture: ComponentFixture<ImportTableExcelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImportTableExcelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportTableExcelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
