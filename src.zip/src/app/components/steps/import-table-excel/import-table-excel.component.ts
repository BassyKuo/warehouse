import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-import-table-excel',
  templateUrl: './import-table-excel.component.html',
  styleUrls: ['./import-table-excel.component.css']
})
export class ImportTableExcelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
