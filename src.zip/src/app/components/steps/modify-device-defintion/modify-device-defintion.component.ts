import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modify-device-defintion',
  templateUrl: './modify-device-defintion.component.html',
  styleUrls: ['./modify-device-defintion.component.css']
})
export class ModifyDeviceDefintionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
