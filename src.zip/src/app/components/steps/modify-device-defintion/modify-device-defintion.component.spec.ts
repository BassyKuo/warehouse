import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyDeviceDefintionComponent } from './modify-device-defintion.component';

describe('ModifyDeviceDefintionComponent', () => {
  let component: ModifyDeviceDefintionComponent;
  let fixture: ComponentFixture<ModifyDeviceDefintionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModifyDeviceDefintionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyDeviceDefintionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
