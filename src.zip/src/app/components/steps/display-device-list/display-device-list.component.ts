import { Component, OnInit, Input } from '@angular/core';
import {MessageService} from 'primeng/api';

import { DeviceInfo, DeviceInfoClass, DeviceDefUnit, DeviceDefUnitClass } from 'src/app/model/deviceinfo';
import { LayerInfo } from 'src/app/model/layerinfo';

@Component({
    selector: 'app-display-device-list',
    templateUrl: './display-device-list.component.html',
    styleUrls: ['./display-device-list.component.css'],
    providers: [MessageService]
})
export class DisplayDeviceListComponent implements OnInit {

    @Input() deviceGrid: DeviceInfo[];
    @Input() tableName: string;
    @Input() layerList: LayerInfo[];
    @Input() typeList: string[];

    requiredTypeBody: boolean;

    layerDefDropDown: any[];
    typeDefDropDown: any[];
    selectedDeviceInfos: DeviceInfo[];
    tmpDevices: { [id: string]: DeviceInfo; } = {};
    tmpDeviceDefs: { [id: string]: DeviceDefUnit[]; } = {};

    constructor(
        private messageService: MessageService) 
    { 
    }

    ngOnInit(): void {
        this.requiredTypeBody = this.typeList.includes('B');
        this.typeDefDropDown = this.typeList.map(type => ({label:type,value:type}));
        this.layerDefDropDown = this.layerList.map(layerInfo => ({label: layerInfo.def, value: layerInfo.name, name: layerInfo.name}));
    }

    checkDuplicatedTypeB(device: DeviceInfo): boolean {
        const type = 'B';
        let filteredTypes = device.def.filter(def => (def.type == type));
        return filteredTypes.length > 1;
    }

    getCountOfTypeB(device: DeviceInfo): number {
        const type = 'B';
        let filteredTypes = device.def.filter(def => (def.type == type));
        return filteredTypes.length;
    }

    checkChangedType(deviceDef: DeviceDefUnit) {
        return deviceDef.type != deviceDef.orig.type;
    }

    checkChangedDeviceName(device: DeviceInfo) {
        return device.name != device.orig.name;
    }

    onRowEditDeviceInit(device: DeviceInfo) {
        let copy = Object.assign(new DeviceInfoClass(), device);
        this.tmpDevices[device.id] = copy;
    }

    onRowEditDeviceSave(device: DeviceInfo, index: number) {
        if (!(JSON.stringify(device) === JSON.stringify(this.tmpDevices[device.id]))) {
            this.deviceGrid[index].isChanged = true;
        }
        delete this.tmpDevices[device.id];
    }

    onRowEditDeviceCancel(device: DeviceInfo, index: number) {
        this.deviceGrid[index] = this.tmpDevices[device.id];
        delete this.tmpDevices[device.id];
    }

    // onRowEditDeviceDefInit(index: number) {
    //     let copy = this.deviceGrid[index].def.map(defUnit => (
    //         Object.assign(new DeviceDefUnitClass(), defUnit)
    //     ));
    //     this.tmpDeviceDefs[index] = copy;
    // }

    // onRowEditDeviceDefSave(index: number) {
    //     delete this.tmpDeviceDefs[index];
    // }

    // onRowEditDeviceDefCancel(index: number) {
    //     this.deviceGrid[index].def = this.tmpDeviceDefs[index];
    //     delete this.tmpDeviceDefs[index];
    // }

}
