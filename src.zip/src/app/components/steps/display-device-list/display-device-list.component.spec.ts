import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayDeviceListComponent } from './display-device-list.component';

describe('DisplayDeviceListComponent', () => {
  let component: DisplayDeviceListComponent;
  let fixture: ComponentFixture<DisplayDeviceListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplayDeviceListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayDeviceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
