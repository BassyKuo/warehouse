import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { HttpEventType, HttpResponse,HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';

import {ButtonModule} from 'primeng/button';
import {FileUploadModule} from 'primeng/fileupload';
import {RadioButtonModule} from 'primeng/radiobutton';
import {MenuItem} from 'primeng/api';
import {ToastModule} from 'primeng/toast';
import {MessageService} from 'primeng/api';
import {DialogService} from 'primeng/dynamicdialog';

import * as XLSX from 'xlsx';

import { DeviceInfo, DeviceDefUnit, DeviceInfoClass, DeviceDefUnitClass } from 'src/app/model/deviceinfo';
import { LayerInfo, LayerInfoClass } from 'src/app/model/layerinfo';

@Component({
  selector: 'app-create-page',
  templateUrl: './create-page.component.html',
  styleUrls: ['./create-page.component.css'],
  providers: [MessageService,DialogService]
})
export class CreatePageComponent implements OnInit {

    displayModal = false;

    stepIdx: number = 0;
    steps: any[];
    message = '';
    step1 = 'import';

    sheetNames = ["Table I", "Table II"];
    typeList1: string[] = ['1','2','3','4','*','B'];
    typeList2: string[] = ['3','4','*'];

    //-- Step 1
    currentFileName: string = "Choose file";
    progress = 0;
    fileInfos: Observable<any>;
    deviceGrid1: DeviceInfo[];
    deviceGrid2: DeviceInfo[];
    layerList: LayerInfo[];   // get from CAD database

    //-- Step 2

    //-- Step 3

    //-- Step 4

    constructor(
        private appService: AppService,
        private messageService: MessageService,
        public dialogService: DialogService) { }

    ngOnInit(): void {
        this.steps = [
            {label: 'Step 1', value:1, footerBack:false, footerNext:true},
            {label: 'Step 2', value:2, footerBack:true , footerNext:true},
            {label: 'Step 3', value:3, footerBack:true , footerNext:false}
        ];

        this.fileInfos = this.appService.downloadDLCTableXls();
    }

    public selectFile(event): void {
        this.currentFileName = event.target.files.item(0).name;
        this.saveXlsToGrid(event);
    }

    // public uploadFile(): void {
    //     this.progress = 0;

    //     this.currentFile = this.selectedFiles.item(0);
    //     this.appService.uploadDLCTableXls(this.currentFile).subscribe(
    //         event => {
    //             if (event.type === HttpEventType.UploadProgress) {
    //                 this.progress = Math.round(100 * event.loaded / event.total);
    //             } else if (event instanceof HttpResponse) {
    //                 this.message = event.body.message;
    //                 this.messageService.add({severity:'success', summary: 'Success', detail: this.message});
    //                 this.fileInfos = this.appService.downloadDLCTableXls();
    //             }
    //         },
    //         err => {
    //             this.progress = 0;
    //             this.message = 'Could not upload the file!';
    //             this.messageService.add({severity:'error', summary: 'Error', detail: this.message});
    //             this.currentFile = undefined;
    //         });
    //         this.selectedFiles = undefined;
    // }

    public prevStep() {
        let stepIdx = this.stepIdx - 1;
        this.stepIdx = (stepIdx > 0) ? stepIdx : 0;
    }

    public nextStep() {
        let stepIdx = this.stepIdx + 1;
        this.stepIdx = (stepIdx < this.steps.length) ? stepIdx : this.steps.length-1;
    }

    public saveXlsToGrid(ev) {
        let workBook = null;
        let jsonData = null;
        let layerList = [];
        const reader = new FileReader();
        const file = ev.target.files[0];
        reader.onload = (event) => {
            const data = reader.result;
            workBook = XLSX.read(data, { type: 'binary' });
            // jsonData = workBook.SheetNames.reduce((initial, name, sheetIdx) => {
            jsonData = this.sheetNames.reduce((initial, name, sheetIdx) => {
                if (workBook.SheetNames.indexOf(name) < 0) {
                    return initial;
                }

                const sheet = workBook.Sheets[name];
                const allTextLines: string[] = XLSX.utils.sheet_to_json(sheet, { header: 1 });

                // console.log(allTextLines);
                /** 0: ['','3: INTERACT\r\n4: NOT INTERACT\r\n*: don't care', '132;97', '132;98', '132;99', '44;47 AND 6;89', '43;23', '43;24', '43;25', '75;77', '75;78']
                    1: ['No', 'Device Name', 'LLA', 'LLB', 'LLC', 'LLC_COM', 'LU_I', 'LU_O', 'LU_P', 'UK_A', 'UK_B']
                    2: [1, 'Device_MOS_01', 3, 4, 3, 4, 4, 3, 3, 4, 3]
                    3: [2, 'Device_MOS_02', 3, 3, 3, 4, 4, 3, 3, 4, 4]
                */

                let layerDef = allTextLines[0].slice(2);
                let layerName = allTextLines[1].slice(2); 
                let deviceDef = {};
                let deviceList = [];
                for(let i = 2; i < allTextLines.length; i++){
                    const deviceNo = allTextLines[i][0];
                    const deviceName = allTextLines[i][1];
                    if (deviceName) {
                        deviceList.push({id: deviceNo, name: deviceName});
                        deviceDef[deviceName] = allTextLines[i].slice(2);
                    }
                }
                for (let k = 0; k < layerName.length; k++) {
                    let layerUnit = new LayerInfoClass();
                    layerUnit.name = layerName[k];
                    layerUnit.def = layerDef[k];
                    layerList.push(layerUnit);
                }

                initial[name] = {};
                initial[name]["layerDef"] = layerDef;
                initial[name]["layerName"] = layerName;
                initial[name]["device"] = deviceDef;
                initial[name]["deviceList"] = deviceList;
                return initial;
            
            }, {});
            if (jsonData == null || Object.keys(jsonData).length < this.sheetNames.length) {
                const miss = this.sheetNames.map(name => "`"+name+"`").join(", ");
                this.messageService.add({severity:'error', summary: 'Error', detail: "Must include "+this.sheetNames.length+" sheets named "+miss+" in excel."});
            } else {
                this.deviceGrid1 = this.convertSheetJsonToGrid(jsonData[this.sheetNames[0]]);
                this.deviceGrid2 = this.convertSheetJsonToGrid(jsonData[this.sheetNames[1]]);
                this.messageService.add({severity:'success', summary: 'Success', detail: ""});
                this.layerList = layerList;
            }
        }
        reader.readAsBinaryString(file);
    }

    private readRowsFromXlsx(sheet: Object) {
        let rows = [];
        for (let cellIdx in sheet) {
            if (sheet[cellIdx] == "s") {
                if (cellIdx.endsWith("1")) {
                    //-- Row 1
                } else if (cellIdx.endsWith("2")) {
                    //-- Row 2
                } else {

                }
            }
        }
    }

    private convertSheetJsonToGrid(sheet: Object) {
        let grid = [];
        let layerDef = sheet["layerDef"];
        let layerName = sheet["layerName"];
        grid = sheet["deviceList"].map(dev => {
            let units = [];
            let deviceId = dev["id"];
            let deviceName = dev["name"];
            let deviceDef = sheet["device"][deviceName];
            for (let i = 0; i < deviceDef.length; i++) {
                let unit = new DeviceDefUnitClass(deviceDef[i], layerName[i], layerDef[i]);
                units.push(unit);
            }
            let info = new DeviceInfoClass(deviceId, deviceName, units);
            return info;
        });
        return grid;
    }

    private setDownloadLink(data) {
        setTimeout(() => {
          const el = document.querySelector("#download");
          el.setAttribute("href", `data:text/json;charset=utf-8,${encodeURIComponent(data)}`);
          el.setAttribute("download", 'xlsxtojson.json');
        }, 1000)
      }

    public clickAddLayerButton(ev) {
        // const ref = this.dialogService.open(CarsListDemo, {
        //     header: 'Choose a Car',
        //     width: '70%'
        // });
        console.log(ev);
    }
    showAddLayerDialog() {
        this.displayModal = true;
    }
}
