import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revision-page',
  templateUrl: './revision-page.component.html',
  styleUrls: ['./revision-page.component.css']
})
export class RevisionPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
