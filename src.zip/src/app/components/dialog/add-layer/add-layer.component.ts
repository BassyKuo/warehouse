import { Component, OnInit, Input } from '@angular/core';

import { LayerInfo } from 'src/app/model/layerinfo';

@Component({
  selector: 'app-add-layer',
  templateUrl: './add-layer.component.html',
  styleUrls: ['./add-layer.component.css']
})
export class AddLayerComponent implements OnInit {

  @Input() layerList: LayerInfo[];

  layerDefDropDown: any[];
  layerDef: string;
  layerName: string;

  constructor() { }

  ngOnInit(): void {
    this.layerDefDropDown = this.layerList.map(layerInfo => ({label: layerInfo.def, value: layerInfo.name, name: layerInfo.name}));
  }

  changeLayerName(ev) {
    this.layerName = ev.value;
  }

}
