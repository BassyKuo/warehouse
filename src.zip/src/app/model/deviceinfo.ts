export interface DeviceInfo {
    id: string;
    name: string;
    def: DeviceDefUnit[];
    status?: string;
    isChanged?: boolean;
    orig: this;

    code?:string;
    description?:string;
}

export interface DeviceDefUnit {
    type: string;       // *,B,1,2,3,4
    layerName: string;  // LA
    layerDef: string;   // 0;9
    isChanged?: boolean;

    orig: this;
}

interface DropDown {
    label: string,
    value: string,
    name: string
}

export class DeviceInfoClass implements DeviceInfo {

    constructor(
        public id: string = "",
        public name: string = "",
        public def: DeviceDefUnit[] = []
        ) {}
    
    status = "";
    isChanged = false;

    orig = Object.assign({}, this);

    public clone() {
        return JSON.parse(JSON.stringify(this));
    }
}

export class DeviceDefUnitClass implements DeviceDefUnit {

    constructor(
        public type: string = "",
        public layerName: string = "",
        public layerDef: string = "",
        ) {}
        
    isChanged = false;

    orig = Object.assign({}, this);

    public clone() {
        return JSON.parse(JSON.stringify(this));
    }
}