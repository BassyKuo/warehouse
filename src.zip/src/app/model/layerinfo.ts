export interface LayerInfo {
    name?: string;  // LA
    def?: string;   // 0;9
    isChanged?: boolean;
}

export class LayerInfoClass implements LayerInfo {
    name = "";
    def = "";
    isChanged = false;
}