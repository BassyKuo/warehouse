export interface HomeMenu {
    label: string,
    value: string,
    disabled: boolean
}
