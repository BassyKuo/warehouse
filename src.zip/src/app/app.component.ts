import { Component } from '@angular/core';
import { SelectItem, PrimeNGConfig } from 'primeng/api';
import { SelectButtonModule } from 'primeng/selectbutton';
import { DropdownModule } from 'primeng/dropdown';
import {TabViewModule} from 'primeng/tabview';
import {ToastModule} from 'primeng/toast';
import {MessageService} from 'primeng/api';

import { HomeMenu } from './model/homemenu';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[MessageService]
})

export class AppComponent {
    title = 'DLC System';

    techOptions: HomeMenu[];
    selectedTech: HomeMenu;

    funcOptions: HomeMenu[];
    selectedFunc: HomeMenu;

    menuOptions: HomeMenu[];
    selectedMenu: HomeMenu;

    constructor(
        private messageService: MessageService,
        private primeNGConfig: PrimeNGConfig
    ) {
        this.techOptions = [
            { label: "N40", value: "N40", disabled: false },
            { label: "N45", value: "N45", disabled: false },
            { label: "N90", value: "N90", disabled: false }
        ];
        this.funcOptions = [
            { label: "HV", value: "hv", disabled: false },
            { label: "BM", value: "bm", disabled: true },
            { label: "BIS", value: "bis", disabled: true }
        ];
        this.menuOptions = [
            { label: "New Create", value: "create", disabled: false },
            { label: "Revision", value: "revision", disabled: false },
            { label: "Query", value: "query", disabled: true }
        ];
    }

    ngOnInit() {
        this.primeNGConfig.ripple = true;
    }
}
